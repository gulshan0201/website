import shovan from '../../assets/shovan.jpg';
import manjarul from '../../assets/manjarul.jpg';
import akhtar from '../../assets/Akhtar.jpg';
import neha from '../../assets/Neha.jpg';
import mustak from '../../assets/Mustak.jpg';


export const data = [
    {
        imgURL: shovan,
        prof: 'Shovan Roy',
        desc: 'Physics Faculty'
    },
    {
        imgURL: manjarul,
        prof: 'Manjarul Sir',
        desc: 'Chemistry Faculty'
    },
    {
        imgURL: akhtar,
        prof: 'Akhtar Sir', 
        desc: 'Physics Faculty'
    },
    {
        imgURL: neha,
        prof: 'Neha Madam',
        desc: 'Biology Faculty'
    },
    {
        imgURL: mustak,
        prof: 'Mustak Sir',
        desc: 'Biology Faculty'
    }

]