import user1 from '../../assets/user1.jpg';
import user2 from '../../assets/user2.jpg';
import user3 from '../../assets/user3.jpg';
import user4 from '../../assets/user4.jpg';


export const data = [
    {
        imgURL: user1,
        title: 'Oliva Joe',
        about: "GATE Qualified",
        des: 'Their natural inquisitiveness mirrors a relentless pursuit of knowledge. Cat students are attentive, observant, and have an uncanny ability to navigate their environment, much like skilled learners navigating the realms of education.',
    },
    {
        imgURL: user2,
        title: 'Alex',
        about: "CAT Qualified",
        des: ' Their natural inquisitiveness mirrors a relentless pursuit of knowledge. Cat students are attentive, observant, and have an uncanny ability to navigate their environment, much like skilled learners navigating the realms of education.',
    },
    {
        imgURL: user3,
        title: 'Adam Derrick',
        about: "MAT Qualified",
        des: 'Their natural inquisitiveness mirrors a relentless pursuit of knowledge. Cat students are attentive, observant, and have an uncanny ability to navigate their environment, much like skilled learners navigating the realms of education.',
    },
    {
        imgURL: user4,
        title: 'James Joe',
        about: "CAT Aspirant",
        des: ' Their natural inquisitiveness mirrors a relentless pursuit of knowledge. Cat students are attentive, observant, and have an uncanny ability to navigate their environment, much like skilled learners navigating the realms of education.',
    },

]