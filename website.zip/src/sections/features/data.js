import calender from '../../assets/calendar.png'
import certificate from '../../assets/certificate.png';
import creativity from '../../assets/creativity.png';
import homework from '../../assets/homework.png';
// import socialmedia from '../../assets/social-media.png';

export const data = [
    {
        icon: calender,
        title: 'calender',
    },
    {
        icon: certificate,
        title: 'certificate',
    },
    {
        icon: creativity,
        title: 'creativity',
    },
    {
        icon: homework,
        title: 'homework',
    }
]