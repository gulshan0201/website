const Data = [
    {
        id: 1,
        link: '#',
        title: 'home',
    },
    {
        id: 2,
        link: '#about',
        title: 'about',
    },
    {
        id: 3,
        link: '#courses',
        title: 'courses',
    },  
    {
        id: 6,
        link: '#contact',
        title: 'contact',
    },

]

export default Data;