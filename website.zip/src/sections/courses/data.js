import course1 from '../../assets/course1.jpg';
import course2 from '../../assets/course2.jpg'
import course3 from '../../assets/course3.jpg';
import course4 from '../../assets/course4.jpg';
import course5 from '../../assets/course5.jpg';
import course6 from '../../assets/course6.jpg';
import course7 from '../../assets/course7.jpg';
import course8 from '../../assets/course8.jpg';



export const data = [
    {
        imgURL: course1,
        title: 'CAT Advance',
        prof: 'ABCD',
        students: '500',
        des: 'lorem23 kjsndkj nskdjcnksn osidnc nsdncl nclskdl nclskdnc nlcksdn nskdjcn nskdjcn ',
    },
    {
        imgURL: course2,
        title: 'CAT Advance',
        prof: 'ABCD',
        students: '200',
        des: 'lorem4 lorem23 kjsndkj nskdjcnksn osidnc nsdncl nclskdl nclskdnc nlcksdn nskdjcn',
    },
    {
        imgURL: course3,
        title: 'CAT Advance',
        prof: 'ABCD',
        students: '100',
        des: 'lorem4 lorem23 kjsndkj nskdjcnksn osidnc nsdncl nclskdl nclskdnc nlcksdn nskdjcn',
    },
    {
        imgURL: course4,
        title: 'CAT Advance',
        prof: 'ABCD',
        students: '120',
        des: 'lorem4 lorem23 kjsndkj nskdjcnksn osidnc nsdncl nclskdl nclskdnc nlcksdn nskdjcn',
    },
    {
        imgURL: course5,
        title: 'CAT Advance',
        prof: 'ABCD',
        students: '90',
        des: 'lorem4 lorem23 kjsndkj nskdjcnksn osidnc nsdncl nclskdl nclskdnc nlcksdn nskdjcn',
    },
    {
        imgURL: course6,
        title: 'CAT Advance',
        prof: 'ABCD',
        students: '130',
        des: 'lorem4 lorem23 kjsndkj nskdjcnksn osidnc nsdncl nclskdl nclskdnc nlcksdn nskdjcn',
    },
    {
        imgURL: course7,
        title: 'CAT Advance',
        prof: 'ABCD',
        students: '100',
        des: 'lorem4 lorem23 kjsndkj nskdjcnksn osidnc nsdncl nclskdl nclskdnc nlcksdn nskdjcn',
    },
    {
        imgURL: course8,
        title: 'CAT Advance',
        prof: 'ABCD',
        students: '90',
        des: 'lorem4 lorem23 kjsndkj nskdjcnksn osidnc nsdncl nclskdl nclskdnc nlcksdn nskdjcn',
    }
]